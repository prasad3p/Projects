package clientApplications;

public class ClientMain {
	
	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
			//Create the object of the class CipherClient
	    	Client C=new Client();	
	    	C.goToFirstStep();
	    
	}

}
