package serverApplications;



public class ServerMain {

	public static void main(String[] args) throws Exception 
	{
		// TODO Auto-generated method stub
			//Create an object of class CipherServer
			Server S = new Server();
			S.receiveMsg();

	}
}
